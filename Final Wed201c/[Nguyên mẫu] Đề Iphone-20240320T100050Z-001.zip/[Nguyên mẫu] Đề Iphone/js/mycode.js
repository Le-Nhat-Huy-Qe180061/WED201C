function CustomerInfo() {
  alert("Thank you for trusting and using our product in the past time");
}
